package bean;

public class CartItems {

	 private int cartId;
	    private int userId;
	    private int dishId;
	    private int quantity;
	    private String dishName;
	    private String description;
	    private double price;
	    private String imageUrl;
	    
	    public int getCartId() {
	        return cartId;
	    }

	    public void setCartId(int cartId) {
	        this.cartId = cartId;
	    }

	    public int getUserId() {
	        return userId;
	    }

	    public void setUserId(int userId) {
	        this.userId = userId;
	    }

	    public int getDishId() {
	        return dishId;
	    }

	    public void setDishId(int dishId) {
	        this.dishId = dishId;
	    }

	    public int getQuantity() {
	        return quantity;
	    }

	    public void setQuantity(int quantity) {
	        this.quantity = quantity;
	    }

	    public String getDishName() {
	        return dishName;
	    }

	    public void setDishName(String dishName) {
	        this.dishName = dishName;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public double getPrice() {
	        return price;
	    }

	    public void setPrice(double price) {
	        this.price = price;
	    }

	    public String getImageUrl() {
	        return imageUrl;
	    }

	    public void setImageUrl(String imageUrl) {
	        this.imageUrl = imageUrl;
	    }
}
