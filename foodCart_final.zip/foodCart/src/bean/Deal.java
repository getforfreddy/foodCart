package bean;

import java.sql.Timestamp;

public class Deal {
	public Deal() {
		super();
	}
	public Deal(int deal_id, String deal_description, String deal_image_url, Timestamp deal_created_at) {
		super();
		this.deal_id = deal_id;
		this.deal_description = deal_description;
		this.deal_image_url = deal_image_url;
		this.deal_created_at = deal_created_at;
	}
	private int deal_id;
    private String deal_description;
    private String deal_image_url;
    private Timestamp deal_created_at;
	public int getDeal_id() {
		return deal_id;
	}
	public void setDeal_id(int deal_id) {
		this.deal_id = deal_id;
	}
	public String getDeal_description() {
		return deal_description;
	}
	public void setDeal_description(String deal_description) {
		this.deal_description = deal_description;
	}
	public String getDeal_image_url() {
		return deal_image_url;
	}
	public void setDeal_image_url(String deal_image_url) {
		this.deal_image_url = deal_image_url;
	}
	public Timestamp getDeal_created_at() {
		return deal_created_at;
	}
	public void setDeal_created_at(Timestamp deal_created_at) {
		this.deal_created_at = deal_created_at;
	}
	@Override
	public String toString() {
		return "Deal [deal_id=" + deal_id + ", deal_description=" + deal_description + ", deal_image_url="
				+ deal_image_url + ", deal_created_at=" + deal_created_at + "]";
	}
}