package bean;

import java.sql.Timestamp;

public class Dish {
    private int dish_id;
    private String dish_name;
    private String description;
    private int price;
    private int category_id;
    private boolean isVegitarian;
    private String image_url;
    private Timestamp created_at;
    private Timestamp updated_at;
	public int getDish_id() {
		return dish_id;
	}
	public void setDish_id(int dish_id) {
		this.dish_id = dish_id;
	}
	public String getDish_name() {
		return dish_name;
	}
	public void setDish_name(String dish_name) {
		this.dish_name = dish_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getCategory_id() {
		return category_id;
	}
	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}
	public boolean isVegitarian() {
		return isVegitarian;
	}
	public void setVegitarian(boolean isVegitarian) {
		this.isVegitarian = isVegitarian;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	public Timestamp getCreated_at() {
		return created_at;
	}
	public void setCreated_at(Timestamp created_at) {
		this.created_at = created_at;
	}
	public Timestamp getUpdated_at() {
		return updated_at;
	}
	public void setUpdated_at(Timestamp updated_at) {
		this.updated_at = updated_at;
	}
	public Dish(int dish_id, String dish_name, String description, int price, int category_id, boolean isVegitarian,
			String image_url, Timestamp created_at, Timestamp updated_at) {
		super();
		this.dish_id = dish_id;
		this.dish_name = dish_name;
		this.description = description;
		this.price = price;
		this.category_id = category_id;
		this.isVegitarian = isVegitarian;
		this.image_url = image_url;
		this.created_at = created_at;
		this.updated_at = updated_at;
	}
	public Dish() {
		super();
	}
	@Override
	public String toString() {
		return "Dish [dish_id=" + dish_id + ", dish_name=" + dish_name + ", description=" + description + ", price="
				+ price + ", category_id=" + category_id + ", isVegitarian=" + isVegitarian + ", image_url=" + image_url
				+ ", created_at=" + created_at + ", updated_at=" + updated_at + "]";
	}

}