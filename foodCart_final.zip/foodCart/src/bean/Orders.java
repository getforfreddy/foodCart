package bean;

import java.sql.Timestamp;

public class Orders {
 public Orders() {
		super();
	}
public Orders(int order_id, int user_id, int dish_id, String dish_name, String image_url, int dish_price,
			int quantity, int total_price, Timestamp order_date, String payment_id) {
		super();
		this.order_id = order_id;
		this.user_id = user_id;
		this.dish_id = dish_id;
		this.dish_name = dish_name;
		this.image_url = image_url;
		this.dish_price = dish_price;
		this.quantity = quantity;
		this.total_price = total_price;
		this.order_date = order_date;
		this.payment_id = payment_id;
	}
private int order_id;
    private int user_id;
    private int dish_id;
    private String dish_name;
    private String image_url;
    private int dish_price;
    private int quantity;
    private int total_price;
    private Timestamp order_date;
    private String payment_id;
	public int getOrder_id() {
		return order_id;
	}
	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}
	public int getUser_id() {
		return user_id;
	}
	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}
	public int getDish_id() {
		return dish_id;
	}
	public void setDish_id(int dish_id) {
		this.dish_id = dish_id;
	}
	public String getDish_name() {
		return dish_name;
	}
	public void setDish_name(String dish_name) {
		this.dish_name = dish_name;
	}
	public String getImage_url() {
		return image_url;
	}
	public void setImage_url(String image_url) {
		this.image_url = image_url;
	}
	public int getDish_price() {
		return dish_price;
	}
	public void setDish_price(int dish_price) {
		this.dish_price = dish_price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getTotal_price() {
		return total_price;
	}
	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}
	public Timestamp getOrder_date() {
		return order_date;
	}
	public void setOrder_date(Timestamp order_date) {
		this.order_date = order_date;
	}
	public String getPayment_id() {
		return payment_id;
	}
	public void setPayment_id(String payment_id) {
		this.payment_id = payment_id;
	}
	@Override
	public String toString() {
		return "orders [order_id=" + order_id + ", user_id=" + user_id + ", dish_id=" + dish_id + ", dish_name="
				+ dish_name + ", image_url=" + image_url + ", dish_price=" + dish_price + ", quantity=" + quantity
				+ ", total_price=" + total_price + ", order_date=" + order_date + ", payment_id=" + payment_id + "]";
	}
}