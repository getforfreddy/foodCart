package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import bean.Category;
import dbconnection.DBConnection;

public class CategoryDao {

	// Method to get all categories
	public List<Category> getAllCategories() {
		List<Category> categoryList = new ArrayList<>();
		String sql = "SELECT * FROM categories";

		try (Connection connection = DBConnection.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql);
				ResultSet rs = stmt.executeQuery()) {
			while (rs.next()) {
				Category category = new Category();
				category.setCategory_id(rs.getInt("category_id"));
				category.setCategory_name(rs.getString("category_name"));
				categoryList.add(category);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return categoryList;
	}

	// Method to get a category by its ID
	public Category getCategoryById(int categoryId) {
		Category category = null;
		String sql = "SELECT * FROM categories WHERE category_id = ?";

		try (Connection connection = DBConnection.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setInt(1, categoryId);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					category = new Category();
					category.setCategory_id(rs.getInt("category_id"));
					category.setCategory_name(rs.getString("category_name"));
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return category;
	}

	// Method to check if a category name already exists
	public boolean isCategoryNameDuplicate(String categoryName) {
		String sql = "SELECT COUNT(*) FROM categories WHERE category_name = ?";

		try (Connection connection = DBConnection.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setString(1, categoryName);
			try (ResultSet rs = stmt.executeQuery()) {
				if (rs.next()) {
					return rs.getInt(1) > 0;
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}

	// Method to add a new category
	public boolean addCategory(Category category) {
		if (isCategoryNameDuplicate(category.getCategory_name())) {
			return false; // Duplicate category name found
		}

		String sql = "INSERT INTO categories (category_name) VALUES (?)";

		try (Connection connection = DBConnection.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setString(1, category.getCategory_name());

			int rowsAffected = stmt.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	// Method to update an existing category
	public boolean updateCategory(Category category) {
		if (isCategoryNameDuplicate(category.getCategory_name())) {
			return false; // Duplicate category name found
		}

		String sql = "UPDATE categories SET category_name = ? WHERE category_id = ?";

		try (Connection connection = DBConnection.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setString(1, category.getCategory_name());
			stmt.setInt(2, category.getCategory_id());

			int rowsAffected = stmt.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	// Method to delete a category by its ID
	public boolean deleteCategory(int categoryId) {
		String sql = "DELETE FROM categories WHERE category_id = ?";

		try (Connection connection = DBConnection.getConnection();
				PreparedStatement stmt = connection.prepareStatement(sql)) {
			stmt.setInt(1, categoryId);

			int rowsAffected = stmt.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
}