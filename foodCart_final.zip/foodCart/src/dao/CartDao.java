package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import bean.CartItems;
import dbconnection.DBConnection;

public class CartDao {

	

    // Method to get items in the cart
    public List<CartItems> getCartItems(int userId) {
        List<CartItems> cartItems = new ArrayList<>();
        String sql = "SELECT * FROM cart WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                CartItems item = new CartItems();
                item.setCartId(rs.getInt("cart_id"));
                item.setUserId(rs.getInt("user_id"));
                item.setDishId(rs.getInt("dish_id"));
                item.setQuantity(rs.getInt("quantity"));
                item.setPrice(rs.getDouble("price"));
                cartItems.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cartItems;
    }
    
    public List<CartItems> getCartItemsWithDishDetails(int userId) {
        List<CartItems> cartItems = new ArrayList<>();
        String sql = "SELECT c.cart_id, c.user_id, c.dish_id, c.quantity, " +
                     "d.dish_name, d.description, d.price, d.image_url " +
                     "FROM cart c " +
                     "JOIN dishes d ON c.dish_id = d.dish_id " +
                     "WHERE c.user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                CartItems item = new CartItems();
                item.setCartId(rs.getInt("cart_id"));
                item.setUserId(rs.getInt("user_id"));
                item.setDishId(rs.getInt("dish_id"));
                item.setQuantity(rs.getInt("quantity"));
                item.setDishName(rs.getString("dish_name"));
                item.setDescription(rs.getString("description"));
                item.setPrice(rs.getInt("price"));
                item.setImageUrl(rs.getString("image_url"));
                cartItems.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cartItems;
    }
    public boolean addItemToCart(int userId, int dishId, int quantity, double price) {
        boolean isAdded = false;
        String selectSql = "SELECT quantity FROM cart WHERE user_id = ? AND dish_id = ?";
        String updateSql = "UPDATE cart SET quantity = quantity + ?, price = price + ? WHERE user_id = ? AND dish_id = ?";
        String insertSql = "INSERT INTO cart (user_id, dish_id, quantity, price) VALUES (?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement selectStmt = connection.prepareStatement(selectSql);
             PreparedStatement updateStmt = connection.prepareStatement(updateSql);
             PreparedStatement insertStmt = connection.prepareStatement(insertSql)) {

            // Check if the item already exists in the cart
            selectStmt.setInt(1, userId);
            selectStmt.setInt(2, dishId);
            ResultSet rs = selectStmt.executeQuery();

            if (rs.next()) {
                // Item exists, update the quantity and price
                updateStmt.setInt(1, quantity);
                updateStmt.setDouble(2, price);
                updateStmt.setInt(3, userId);
                updateStmt.setInt(4, dishId);

                int rowsUpdated = updateStmt.executeUpdate();
                if (rowsUpdated > 0) {
                    isAdded = true;
                }
            } else {
                // Item does not exist, insert a new row
                insertStmt.setInt(1, userId);
                insertStmt.setInt(2, dishId);
                insertStmt.setInt(3, quantity);
                insertStmt.setDouble(4, price);

                int rowsInserted = insertStmt.executeUpdate();
                if (rowsInserted > 0) {
                    isAdded = true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isAdded;
    }
    public boolean deleteItemFromCart(int userId, int dishId) {
        boolean isDeleted = false;
        String sql = "DELETE FROM cart WHERE user_id = ? AND dish_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, dishId);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                isDeleted = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isDeleted;
    }
    public boolean updateCartItem(int userId, int dishId, int newQuantity) {
        boolean isUpdated = false;
        String sql = "UPDATE cart SET quantity = ? WHERE user_id = ? AND dish_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {

            // Check if the new quantity is valid (greater than 0)
            if (newQuantity > 0) {
                stmt.setInt(1, newQuantity);
                stmt.setInt(2, userId);
                stmt.setInt(3, dishId);

                int rowsAffected = stmt.executeUpdate();
                isUpdated = rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isUpdated;
    }
 // Method to clear the cart for a specific user
    public boolean clearCart(int userId) {
        boolean isCleared = false;
        String sql = "DELETE FROM cart WHERE user_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, userId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                isCleared = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return isCleared;
    }


}