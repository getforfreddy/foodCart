package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import bean.Deal;
import dbconnection.DBConnection;

public class DealDao {

    // Method to add a new deal
    public boolean addDeal(Deal deal) {
        String sql = "INSERT INTO deals (deal_description, deal_image_url) VALUES (?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, deal.getDeal_description());
            pstmt.setString(2, deal.getDeal_image_url());
            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to update an existing deal
    public boolean updateDeal(Deal deal) {
        String sql = "UPDATE deals SET deal_description = ?, deal_image_url = ? WHERE deal_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, deal.getDeal_description());
            pstmt.setString(2, deal.getDeal_image_url());
            pstmt.setInt(3, deal.getDeal_id());
            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete a deal by ID
    public boolean deleteDeal(int deal_id) {
        String sql = "DELETE FROM deals WHERE deal_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, deal_id);
            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to get a deal by ID
    public Deal getDealById(int deal_id) {
        String sql = "SELECT * FROM deals WHERE deal_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, deal_id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Deal(
                    rs.getInt("deal_id"),
                    rs.getString("deal_description"),
                    rs.getString("deal_image_url"),
                    rs.getTimestamp("deal_created_at")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Method to get all deals
    public List<Deal> getAllDeals() {
        List<Deal> deals = new ArrayList<>();
        String sql = "SELECT * FROM deals";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                deals.add(new Deal(
                    rs.getInt("deal_id"),
                    rs.getString("deal_description"),
                    rs.getString("deal_image_url"),
                    rs.getTimestamp("deal_created_at")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return deals;
    }
}