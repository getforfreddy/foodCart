package dao;

import bean.Orders;
import dbconnection.DBConnection;

import bean.CartItems;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDao {

	 // Updated method to save order with payment ID and total amount
    public void saveOrder(int userId, List<CartItems> cartItems, String razorpayPaymentId, double totalAmount) throws SQLException {
        String insertOrderSql = "INSERT INTO orders (user_id, dish_id, dish_name, image_url, dish_price, quantity, total_price, order_date, payment_id) VALUES (?, ?, ?, ?, ?, ?, ?, Now(), ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement pstmt = connection.prepareStatement(insertOrderSql)) {

            connection.setAutoCommit(false); // Start transaction

            for (CartItems item : cartItems) {
                pstmt.setInt(1, userId);
                pstmt.setInt(2, item.getDishId()); // Assuming CartItem has getDishId()
                pstmt.setString(3, item.getDishName());
                pstmt.setString(4, item.getImageUrl());
                pstmt.setDouble(5, item.getPrice());
                pstmt.setInt(6, item.getQuantity());
                pstmt.setDouble(7, item.getQuantity() * item.getPrice());
                pstmt.setString(8, razorpayPaymentId); // Set payment_id
                pstmt.addBatch();
            }

            pstmt.executeBatch(); // Execute all batch inserts
            connection.commit(); // Commit transaction
        } catch (SQLException e) {
            e.printStackTrace();
            throw e; // Re-throw exception to handle it in the calling method
        }
    }


    public List<Orders> getAllOrders() {
        List<Orders> ordersList = new ArrayList<>();
        String query = "SELECT * FROM orders";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Orders order = new Orders(
                    rs.getInt("order_id"),
                    rs.getInt("user_id"),
                    rs.getInt("dish_id"),
                    rs.getString("dish_name"),
                    rs.getString("image_url"),
                    rs.getInt("dish_price"),
                    rs.getInt("quantity"),
                    rs.getInt("total_price"),
                    rs.getTimestamp("order_date"),
                    rs.getString("payment_id")
                );
                ordersList.add(order);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching all orders: " + e.getMessage());
        }
        return ordersList;
    }


    // Other methods...

    public List<Orders> getOrdersByUserId(int userId) {
        List<Orders> ordersList = new ArrayList<>();
        String query = "SELECT * FROM orders WHERE user_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
             
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Orders order = new Orders(
                    rs.getInt("order_id"),
                    rs.getInt("user_id"),
                    rs.getInt("dish_id"),
                    rs.getString("dish_name"),
                    rs.getString("image_url"),
                    rs.getInt("dish_price"),
                    rs.getInt("quantity"),
                    rs.getInt("total_price"),
                    rs.getTimestamp("order_date"),
                    rs.getString("payment_id")
                );
                ordersList.add(order);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching orders by user ID: " + e.getMessage());
        }
        return ordersList;
    }
    public int getOrderCount() {
        int count = 0;
        String query = "SELECT COUNT(*) AS total FROM orders";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
             
            if (rs.next()) {
                count = rs.getInt("total");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching order count: " + e.getMessage());
        }
        return count;
    }
}