package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import bean.Category;
import bean.Dish;
import dbconnection.DBConnection;

public class DishDao {

    // Method to get all dishes
    public List<Dish> getAllDishes() {
        List<Dish> dishList = new ArrayList<>();
        String sql = "SELECT * FROM dishes";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Dish dish = new Dish();
                dish.setDish_id(rs.getInt("dish_id"));
                dish.setDish_name(rs.getString("dish_name"));
                dish.setDescription(rs.getString("description"));
                dish.setPrice(rs.getInt("price"));
                dish.setCategory_id(rs.getInt("category_id"));
                dish.setVegitarian(rs.getBoolean("is_vegitarian"));
                dish.setImage_url(rs.getString("image_url"));
                dish.setCreated_at(rs.getTimestamp("created_at"));
                dish.setUpdated_at(rs.getTimestamp("updated_at"));
                dishList.add(dish);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dishList;
    }

    // Method to get a dish by its ID
    public Dish getDishById(int dishId) {
        Dish dish = null;
        String sql = "SELECT * FROM dishes WHERE dish_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, dishId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    dish = new Dish();
                    dish.setDish_id(rs.getInt("dish_id"));
                    dish.setDish_name(rs.getString("dish_name"));
                    dish.setDescription(rs.getString("description"));
                    dish.setPrice(rs.getInt("price"));
                    dish.setCategory_id(rs.getInt("category_id"));
                    dish.setVegitarian(rs.getBoolean("is_vegitarian"));
                    dish.setImage_url(rs.getString("image_url"));
                    dish.setCreated_at(rs.getTimestamp("created_at"));
                    dish.setUpdated_at(rs.getTimestamp("updated_at"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return dish;
    }

    // Method to check if a dish name already exists
    public boolean isDishNameDuplicate(String dishName, int dishId) {
        String sql = "SELECT COUNT(*) FROM dishes WHERE dish_name = ? AND dish_id != ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, dishName);
            stmt.setInt(2, dishId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    // Method to add a new dish
    public boolean addDish(Dish dish) {
        if (isDishNameDuplicate(dish.getDish_name(), 0)) {
            return false; // Duplicate dish name found
        }

        String sql = "INSERT INTO dishes (dish_name, description, price, category_id, is_vegitarian, image_url) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, dish.getDish_name());
            stmt.setString(2, dish.getDescription());
            stmt.setInt(3, dish.getPrice());
            stmt.setInt(4, dish.getCategory_id());
            stmt.setBoolean(5, dish.isVegitarian());
            stmt.setString(6, dish.getImage_url());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to update an existing dish
    public boolean updateDish(Dish dish) {
        if (isDishNameDuplicate(dish.getDish_name(), dish.getDish_id())) {
            return false; // Duplicate dish name found
        }

        String sql = "UPDATE dishes SET dish_name = ?, description = ?, price = ?, category_id = ?, is_vegitarian = ?, image_url = ?, updated_at = CURRENT_TIMESTAMP WHERE dish_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, dish.getDish_name());
            stmt.setString(2, dish.getDescription());
            stmt.setInt(3, dish.getPrice());
            stmt.setInt(4, dish.getCategory_id());
            stmt.setBoolean(5, dish.isVegitarian());
            stmt.setString(6, dish.getImage_url());
            stmt.setInt(7, dish.getDish_id());

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete a dish by its ID
    public boolean deleteDish(int dishId) {
        String sql = "DELETE FROM dishes WHERE dish_id = ?";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, dishId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public Map<Category, List<Dish>> getMenu() {
        Map<Category, List<Dish>> menuMap = new LinkedHashMap<>();
        String sql = "SELECT c.*, d.* " +
                     "FROM categories c " +
                     "LEFT JOIN dishes d ON c.category_id = d.category_id " +
                     "ORDER BY c.category_name, d.dish_name";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            Category currentCategory = null;
            List<Dish> dishList = null;

            while (rs.next()) {
                // Process Category
                if (currentCategory == null || currentCategory.getCategory_id() != rs.getInt("c.category_id")) {
                    if (currentCategory != null) {
                        // Add the previous category and its dishes to the map
                        menuMap.put(currentCategory, dishList);
                    }
                    // Create a new Category object
                    currentCategory = new Category();
                    currentCategory.setCategory_id(rs.getInt("c.category_id"));
                    currentCategory.setCategory_name(rs.getString("c.category_name"));

                    // Start a new dish list for the new category
                    dishList = new ArrayList<>();
                }

                // Process Dish
                if (rs.getInt("d.dish_id") > 0) {
                    Dish dish = new Dish();
                    dish.setDish_id(rs.getInt("d.dish_id"));
                    dish.setDish_name(rs.getString("d.dish_name"));
                    dish.setDescription(rs.getString("d.description"));
                    dish.setPrice(rs.getInt("d.price"));
                    dish.setCategory_id(rs.getInt("d.category_id"));
                    dish.setVegitarian(rs.getBoolean("d.is_vegitarian"));
                    dish.setImage_url(rs.getString("d.image_url"));
                    dish.setCreated_at(rs.getTimestamp("d.created_at"));
                    dish.setUpdated_at(rs.getTimestamp("d.updated_at"));
                    dishList.add(dish);
                }
            }

            // Add the last category and its dishes to the map
            if (currentCategory != null) {
                menuMap.put(currentCategory, dishList);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return menuMap;
    }
    public int getDishCount() {
        int count = 0;
        String sql = "SELECT COUNT(*) AS dish_count FROM dishes";

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {
            if (rs.next()) {
                count = rs.getInt("dish_count");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return count;
    }
}